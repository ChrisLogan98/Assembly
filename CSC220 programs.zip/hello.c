/* ----------------------------------------------------------------------------------------
 Writes "Hello World" to the console.
 To compile and run:

 gcc hello.c && ./a.out

 ----------------------------------------------------------------------------------------*/

/*standard input/output library*/
#include <stdio.h>

int main() {
	/*print hello world to console*/
	printf("Hello World, again\n");
	return 0;
}

